// const nav_item = document.querySelector('nav-item');
// const a = document.querySelectorAll('a');

// a.forEach(el => {
//     el.addEventListener('click', function() {
//         nav_item.querySelector('.active').classList.remove('active')

//         el.classList.add('active');
//     });
// });